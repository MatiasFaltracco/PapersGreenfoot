import greenfoot.*;

public class FichaAlumno extends Documento {
    private GeneradorDocumentos.FichaData data;

    public FichaAlumno(GeneradorDocumentos.FichaData data) {
        this.data = data;
        renderizar();
    }

    private void renderizar() {
        GreenfootImage canvas;

        try {
            canvas = new GreenfootImage("ficha_base.png");
        } catch (Exception e) {
            canvas = new GreenfootImage(240, 320);
            canvas.setColor(Color.WHITE);
            canvas.fill();
            canvas.setColor(Color.BLACK);
            canvas.drawRect(0, 0, 239, 319);
            canvas.drawString("FICHA DE ESTUDIANTE", 15, 25);
        }

        Font fuente = new Font("Courier New", true, false, 12);
        canvas.setFont(fuente);
        canvas.setColor(Color.BLACK);

        // Escritura de textos
        canvas.drawString(data.legajo, 110, 105);
        canvas.drawString(data.apellido + ", " + data.nombre, 185, 148);
        canvas.drawString(data.turno, 195, 192);
        canvas.drawString(data.regularidad, 175, 235);
        canvas.drawString(data.fechaCaducidad, 140, 278);

        setImage(canvas);
    }

    public GeneradorDocumentos.FichaData getData() { return data; }
}