import greenfoot.*;

public class MyWorld extends World
{
    private boolean esTramiteValido;
    private Estudiante estudianteActual;
    private DNI dniActual;
    private FichaAlumno fichaActual;

    public MyWorld()
    {    
        super(924, 641, 1); 
        generarNuevoEstudiante();
    }

    public void generarNuevoEstudiante() {
        // Limpieza de objetos de rondas anteriores
        if (estudianteActual != null) removeObject(estudianteActual);
        if (dniActual != null) removeObject(dniActual);
        if (fichaActual != null) removeObject(fichaActual);

        // 1. Instanciamos al nuevo estudiante
        estudianteActual = new Estudiante();
        addObject(estudianteActual, 260, 310);
        
        // 2. Generamos la documentación asociando la ruta de la foto del estudiante
        GeneradorDocumentos.PaqueteDocumentos paquete = GeneradorDocumentos.generar(estudianteActual.getRutaFoto());
        this.esTramiteValido = paquete.esValidoGlobal;

        // 3. Instanciamos los dos actores de documentos
        dniActual = new DNI(paquete.dni);
        fichaActual = new FichaAlumno(paquete.ficha);

        // 4. Ubicación en la mesa
        addObject(dniActual, 380, 510);
        addObject(fichaActual, 620, 510);
    }

    public boolean esTramiteValido() {
        return esTramiteValido;
    }
}