import greenfoot.*;

public class GeneradorDocumentos {

    public static final String[] NOMBRES = {
        "Nicolás", "Mateo", "Joaquín", "Lucas", "Santiago", 
        "Agustín", "Facundo", "Gonzalo", "Tomás", "Ignacio"
    };

    public static final String[] APELLIDOS = {
        "González", "Rodríguez", "Gómez", "Fernández", "López", 
        "Díaz", "Martínez", "Pérez", "Sánchez", "Romero"
    };

    public static final String[] PROVINCIAS = {
        "Córdoba", "Buenos Aires", "Santa Fe", "Mendoza", "Tucumán", "Entre Ríos"
    };

    public static final String[] TURNOS = {
        "Mañana", "Mediodía", "Tarde", "Noche"
    };

    public static class DNIData {
        public String nombre, apellido, legajo, numeroDni;
        public String fechaNacimiento, pais, provincia, fechaCaducidad, fotoRuta;
    }

    public static class FichaData {
        public String nombre, apellido, legajo, turno, regularidad, fechaCaducidad;
    }

    public static class PaqueteDocumentos {
        public DNIData dni;
        public FichaData ficha;
        public boolean esValidoGlobal;

        public PaqueteDocumentos(DNIData dni, FichaData ficha, boolean esValidoGlobal) {
            this.dni = dni;
            this.ficha = ficha;
            this.esValidoGlobal = esValidoGlobal;
        }
    }

    public static PaqueteDocumentos generar(String fotoRutaEstudiante) {
        String nombreBase = NOMBRES[Greenfoot.getRandomNumber(NOMBRES.length)];
        String apellidoBase = APELLIDOS[Greenfoot.getRandomNumber(APELLIDOS.length)];
        String legajoBase = String.format("%05d", 10000 + Greenfoot.getRandomNumber(90000));
        
        DNIData dni = new DNIData();
        FichaData ficha = new FichaData();

        // Datos cosméticos (no afectan la validez)
        dni.fotoRuta = fotoRutaEstudiante;
        dni.numeroDni = String.valueOf(33000000 + Greenfoot.getRandomNumber(6000000));
        dni.fechaNacimiento = generarFechaNacimiento();
        dni.pais = "Argentina";
        dni.provincia = PROVINCIAS[Greenfoot.getRandomNumber(PROVINCIAS.length)];

        ficha.turno = TURNOS[Greenfoot.getRandomNumber(TURNOS.length)];
        ficha.regularidad = (Greenfoot.getRandomNumber(10) < 8) ? "Regular" : "No Regular";

        // Asignación base igual en ambos
        dni.nombre = nombreBase;
        dni.apellido = apellidoBase;
        dni.legajo = legajoBase;
        dni.fechaCaducidad = generarFechaValida();

        ficha.nombre = nombreBase;
        ficha.apellido = apellidoBase;
        ficha.legajo = legajoBase;
        ficha.fechaCaducidad = generarFechaValida();

        // Moneda 1: Validez global (50% / 50%)
        boolean esValidoGlobal = Greenfoot.getRandomNumber(2) == 1;

        if (!esValidoGlobal) {
            // Moneda 2: ¿Lleva el error el DNI o la Ficha?
            boolean errorEnDNI = Greenfoot.getRandomNumber(2) == 0;

            // Elección de UN solo error
            int tipoError = Greenfoot.getRandomNumber(3); // 0 = Nombre, 1 = Legajo, 2 = Vencimiento

            if (tipoError == 0) {
                String nuevoNombre = NOMBRES[Greenfoot.getRandomNumber(NOMBRES.length)];
                String nuevoApellido = APELLIDOS[Greenfoot.getRandomNumber(APELLIDOS.length)];
                
                if (errorEnDNI) {
                    dni.nombre = nuevoNombre;
                    dni.apellido = nuevoApellido;
                } else {
                    ficha.nombre = nuevoNombre;
                    ficha.apellido = nuevoApellido;
                }
            } else if (tipoError == 1) {
                String nuevoLegajo = String.format("%05d", 10000 + Greenfoot.getRandomNumber(90000));
                if (errorEnDNI) {
                    dni.legajo = nuevoLegajo;
                } else {
                    ficha.legajo = nuevoLegajo;
                }
            } else if (tipoError == 2) {
                String fechaVencida = generarFechaVencida();
                if (errorEnDNI) {
                    dni.fechaCaducidad = fechaVencida;
                } else {
                    ficha.fechaCaducidad = fechaVencida;
                }
            }
        }

        return new PaqueteDocumentos(dni, ficha, esValidoGlobal);
    }

    private static String generarFechaValida() {
        int dia = 1 + Greenfoot.getRandomNumber(28);
        int mes = 1 + Greenfoot.getRandomNumber(12);
        int anio = 2011 + Greenfoot.getRandomNumber(5);
        return String.format("%02d/%02d/%04d", dia, mes, anio);
    }

    private static String generarFechaVencida() {
        int anio = 2008 + Greenfoot.getRandomNumber(3);
        int mes = 1 + Greenfoot.getRandomNumber(12);
        int dia = 1 + Greenfoot.getRandomNumber(28);
        if (anio == 2010 && mes > 7) mes = 1 + Greenfoot.getRandomNumber(6);
        return String.format("%02d/%02d/%04d", dia, mes, anio);
    }

    private static String generarFechaNacimiento() {
        int dia = 1 + Greenfoot.getRandomNumber(28);
        int mes = 1 + Greenfoot.getRandomNumber(12);
        int anio = 1985 + Greenfoot.getRandomNumber(8);
        return String.format("%02d/%02d/%04d", dia, mes, anio);
    }
}