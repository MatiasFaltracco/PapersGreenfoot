import greenfoot.*;

public class Estudiante extends Actor
{
    private int anchoActual = 150;
    private int altoActual = 293;
    private final int tamaño_final = 250;
    private final int posicion_X_final = 450;
    private final int velocidad_crecimiento = 2; 

    private String rutaFotoElegida;
    private GreenfootImage imagenOriginal;

    public Estudiante() {
        this.rutaFotoElegida = elegirRutaSprite();
        this.imagenOriginal = cargarImagenSegura(this.rutaFotoElegida, anchoActual, altoActual);
        reescalar();
    }
    
    private String elegirRutaSprite() {
        // Rutas relativas a la carpeta images/ del proyecto
        String[] rutas = {
            "Personajes/P1.png",
            "Personajes/P2.png",
            "Personajes/P3.png"
        };
        int indice = Greenfoot.getRandomNumber(rutas.length);
        return rutas[indice];
    }
    
    public String getRutaFoto() {
        return rutaFotoElegida;
    }
    
    public void reescalar() {
        GreenfootImage copia = new GreenfootImage(imagenOriginal);
        copia.scale(anchoActual, altoActual);
        setImage(copia);
    }

    public void act() 
    {
        if (anchoActual < tamaño_final) {
            anchoActual += velocidad_crecimiento;
            altoActual += velocidad_crecimiento;
            reescalar();
            setLocation(getX(), getY() - (velocidad_crecimiento / 2));
        } else {
            if (getX() < posicion_X_final) {
                setLocation(getX() + velocidad_crecimiento, getY());
            } else if (getX() > posicion_X_final) {
                setLocation(getX() - velocidad_crecimiento, getY());
            } 
        }
    }

    private GreenfootImage cargarImagenSegura(String ruta, int ancho, int alto) {
        try {
            return new GreenfootImage(ruta);
        } catch (Exception e) {
            // Reemplazo en pantalla si el archivo PNG no se encuentra
            GreenfootImage placeholder = new GreenfootImage(ancho, alto);
            placeholder.setColor(Color.LIGHT_GRAY);
            placeholder.fill();
            placeholder.setColor(Color.BLACK);
            placeholder.drawString("Estudiante", ancho / 4, alto / 2);
            return placeholder;
        }
    }
}