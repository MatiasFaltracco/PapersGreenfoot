import greenfoot.*;

public class DNI extends Documento {
    private GeneradorDocumentos.DNIData data;

    public DNI(GeneradorDocumentos.DNIData data) {
        this.data = data;
        renderizar();
    }

    private void renderizar() {
        GreenfootImage canvas;

        try {
            canvas = new GreenfootImage("dni_base.png");
        } catch (Exception e) {
            canvas = new GreenfootImage(460, 310);
            canvas.setColor(new Color(220, 235, 245));
            canvas.fill();
        }

        // Fuente para encajar bien sobre las líneas
        Font fuente = new Font("Courier New", true, false, 15);
        canvas.setFont(fuente);
        canvas.setColor(Color.BLACK);

        // 1. DIBUJAR FOTO EN EL RECUADRO IZQUIERDO ("FOTO")
        if (data.fotoRuta != null && !data.fotoRuta.isEmpty()) {
            try {
                GreenfootImage foto = new GreenfootImage(data.fotoRuta);
                foto.scale(125, 175);         // Tamaño ajustado al marco
                canvas.drawImage(foto, 68, 90); // Posición (X: 48, Y: 72)
            } catch (Exception e) {
                // Silencioso si falla
            }
        }

        // 2. DIBUJAR TEXTOS SOBRE LAS LÍNEAS DE LA DERECHA
        canvas.drawString(data.nombre, 330, 118);          // Nombre
        canvas.drawString(data.apellido, 336, 148);        // Apellido
        canvas.drawString(data.numeroDni, 340, 178);       // DNI Nº
        canvas.drawString(data.fechaNacimiento, 380, 208); // Fecha de Nac.
        canvas.drawString(data.pais, 305, 238);            // País
        canvas.drawString(data.provincia, 375, 268);       // Provincia
        canvas.drawString(data.legajo, 422, 298);          // Legajo
        canvas.drawString(data.fechaCaducidad, 375, 330);  // Caducidad

        setImage(canvas);
    }

    public GeneradorDocumentos.DNIData getData() { return data; }
}