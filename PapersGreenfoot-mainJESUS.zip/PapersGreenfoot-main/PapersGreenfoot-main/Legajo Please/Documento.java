import greenfoot.*;

public class Documento extends Actor {
    private boolean arrastrando = false;
    private int offsetX = 0;
    private int offsetY = 0;

    public void act() {
        gestionarArrastre();
    }

    private void gestionarArrastre() {
        if (Greenfoot.mousePressed(this)) {
            arrastrando = true;
            MouseInfo mouse = Greenfoot.getMouseInfo();
            if (mouse != null) {
                offsetX = getX() - mouse.getX();
                offsetY = getY() - mouse.getY();
            }
        }

        if (arrastrando && Greenfoot.mouseDragged(null)) {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            if (mouse != null) {
                setLocation(mouse.getX() + offsetX, mouse.getY() + offsetY);
            }
        }

        if (Greenfoot.mouseClicked(null) || Greenfoot.mouseDragEnded(null)) {
            arrastrando = false;
        }
    }
}